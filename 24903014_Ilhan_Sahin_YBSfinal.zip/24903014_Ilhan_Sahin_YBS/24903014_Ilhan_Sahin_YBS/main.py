"""
main.py
-------
Kişisel Finans ve Harcama Takip Sistemi – Ana Uygulama
Konsol menü döngüsü; tüm modülleri bir araya getirir.

Kullanım:
    python main.py
"""

import sys

from finans_modeli import FinansYoneticisi
from islem_yonetimi import gelir_ekle, gider_ekle, islemleri_listele, islem_sil
from dosya_islemleri import csv_menu, csv_kaydet, csv_oku, VARSAYILAN_CSV
from analiz import analiz_goster
from gorsellestirme import grafik_menu
from excel_aktar import excel_aktar
from utils import menu_goster, baslik_yazdir

import os


# ====================================================================== #
#  Başlangıç Ekranı                                                       #
# ====================================================================== #

def hosgeldin() -> None:
    """Uygulama açılış ekranını gösterir."""
    print("\n" + "═" * 52)
    print("     💰  KİŞİSEL FİNANS TAKİP SİSTEMİ  💰")
    print("        Python Programlama II – Final Proje")
    print("═" * 52)
    print("  Tüm veriler CSV'ye otomatik yedeklenir.")
    print("  Excel aktarımı için menüden seçim yapın.")
    print("═" * 52)


# ====================================================================== #
#  Ana Döngü                                                              #
# ====================================================================== #

def main() -> None:
    """Uygulamanın ana giriş noktası."""
    hosgeldin()

    yonetici = FinansYoneticisi()

    # Önceki oturuma ait CSV varsa otomatik yükle
    if os.path.exists(VARSAYILAN_CSV):
        print(f"\n  🔄  '{VARSAYILAN_CSV}' bulundu, yükleniyor...")
        csv_oku(yonetici, VARSAYILAN_CSV)

    while True:
        menu_goster()

        try:
            secim = input("  Seçiminiz: ").strip()
        except (KeyboardInterrupt, EOFError):
            secim = "0"

        if secim == "1":
            gelir_ekle(yonetici)

        elif secim == "2":
            gider_ekle(yonetici)

        elif secim == "3":
            islemleri_listele(yonetici)

        elif secim == "4":
            analiz_goster(yonetici)

        elif secim == "5":
            grafik_menu(yonetici)

        elif secim == "6":
            csv_menu(yonetici)

        elif secim == "7":
            baslik_yazdir("📥  EXCEL'E AKTAR")
            dosya = input(f"  Dosya adı [finans_raporu.xlsx]: ").strip() or "finans_raporu.xlsx"
            excel_aktar(yonetici, dosya)

        elif secim == "8":
            islem_sil(yonetici)

        elif secim == "0":
            baslik_yazdir("🚪  ÇIKIŞ")
            if yonetici.tum_islemler():
                print("  Veriler otomatik kaydediliyor...")
                csv_kaydet(yonetici, VARSAYILAN_CSV)
            print("  Görüşürüz! 👋")
            sys.exit(0)

        else:
            print("\n  ⚠  Geçersiz seçim. Lütfen menüden bir numara giriniz.")


if __name__ == "__main__":
    main()
