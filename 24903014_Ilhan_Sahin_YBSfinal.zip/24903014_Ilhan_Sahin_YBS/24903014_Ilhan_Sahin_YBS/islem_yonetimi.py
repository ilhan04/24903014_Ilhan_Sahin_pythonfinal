"""
islem_yonetimi.py
-----------------
Kişisel Finans ve Harcama Takip Sistemi - İşlem Yönetimi
Gelir/gider ekleme, listeleme ve silme işlemleri.
"""

from finans_modeli import Islem, FinansYoneticisi
from utils import (
    benzersiz_id_olustur,
    guvenli_tutar_al,
    guvenli_tarih_al,
    guvenli_aciklama_al,
    baslik_yazdir,
    onay_al,
)


# ====================================================================== #
#  Ekleme İşlemleri                                                       #
# ====================================================================== #

def gelir_ekle(yonetici: FinansYoneticisi) -> None:
    """
    Kullanıcıdan gelir bilgilerini alarak yonetici.gelirler listesine ekler.

    Parameters
    ----------
    yonetici : FinansYoneticisi
        İşlemlerin tutulduğu merkezi nesne.
    """
    baslik_yazdir("➕  YENİ GELİR EKLE")

    tutar = guvenli_tutar_al("  Tutar (TL)    : ")
    tarih = guvenli_tarih_al("  Tarih          ")
    aciklama = guvenli_aciklama_al("  Açıklama/Kategori: ")

    yeni_id = benzersiz_id_olustur(yonetici.gelirler, yonetici.giderler)
    islem = Islem(
        id=yeni_id,
        tutar=tutar,
        tarih=tarih,
        aciklama=aciklama,
        tip="gelir",
    )
    yonetici.gelirler.append(islem)
    print(f"\n  ✅  Gelir kaydedildi → {islem}")


def gider_ekle(yonetici: FinansYoneticisi) -> None:
    """
    Kullanıcıdan gider bilgilerini alarak yonetici.giderler listesine ekler.

    Parameters
    ----------
    yonetici : FinansYoneticisi
        İşlemlerin tutulduğu merkezi nesne.
    """
    baslik_yazdir("➖  YENİ GİDER EKLE")

    tutar = guvenli_tutar_al("  Tutar (TL)    : ")
    tarih = guvenli_tarih_al("  Tarih          ")
    aciklama = guvenli_aciklama_al("  Açıklama/Kategori: ")

    yeni_id = benzersiz_id_olustur(yonetici.gelirler, yonetici.giderler)
    islem = Islem(
        id=yeni_id,
        tutar=tutar,
        tarih=tarih,
        aciklama=aciklama,
        tip="gider",
    )
    yonetici.giderler.append(islem)
    print(f"\n  ✅  Gider kaydedildi → {islem}")


# ====================================================================== #
#  Listeleme                                                               #
# ====================================================================== #

def islemleri_listele(yonetici: FinansYoneticisi) -> None:
    """
    Tüm gelir ve gider kayıtlarını tarih sırasına göre düzenli şekilde
    ekrana yazdırır. Net bakiyeyi de gösterir.

    Parameters
    ----------
    yonetici : FinansYoneticisi
        İşlemlerin tutulduğu merkezi nesne.
    """
    baslik_yazdir("📋  TÜM İŞLEMLER")

    tum = sorted(yonetici.tum_islemler(), key=lambda x: x.tarih)

    if not tum:
        print("  ℹ  Henüz kayıtlı işlem yok.")
        return

    print(f"  {'ID':>4}  {'TARİH':^12}  {'TUTAR':>12}  {'TİP':^10}  AÇIKLAMA")
    print("  " + "─" * 62)

    for i in tum:
        sembol = "+" if i.tip == "gelir" else "-"
        renk_ac = "\033[92m" if i.tip == "gelir" else "\033[91m"
        renk_kapat = "\033[0m"
        print(
            f"  {i.id:>4}  {i.tarih:^12}  "
            f"{renk_ac}{sembol}{i.tutar:>10.2f} TL{renk_kapat}  "
            f"{('(' + i.tip.upper() + ')'):^10}  {i.aciklama}"
        )

    print("  " + "─" * 62)
    print(f"  {'Toplam Gelir:':>30}  \033[92m+{yonetici.toplam_gelir():>10.2f} TL\033[0m")
    print(f"  {'Toplam Gider:':>30}  \033[91m-{yonetici.toplam_gider():>10.2f} TL\033[0m")

    net = yonetici.net_bakiye()
    renk = "\033[92m" if net >= 0 else "\033[91m"
    print(f"  {'Net Bakiye:':>30}  {renk}{net:>+11.2f} TL\033[0m")


# ====================================================================== #
#  Silme                                                                   #
# ====================================================================== #

def islem_sil(yonetici: FinansYoneticisi) -> None:
    """
    Kullanıcının girdiği ID'ye sahip işlemi ilgili listeden siler.

    Parameters
    ----------
    yonetici : FinansYoneticisi
        İşlemlerin tutulduğu merkezi nesne.
    """
    baslik_yazdir("🗑   İŞLEM SİL")

    if not yonetici.tum_islemler():
        print("  ℹ  Silinecek kayıt yok.")
        return

    try:
        hedef_id = int(input("  Silmek istediğiniz işlemin ID'si: ").strip())
    except ValueError:
        print("  ⚠  Geçersiz ID formatı.")
        return

    # Gelirler içinde ara
    for i, islem in enumerate(yonetici.gelirler):
        if islem.id == hedef_id:
            if onay_al(f"  '{islem}' silinsin mi?"):
                yonetici.gelirler.pop(i)
                print("  ✅  Gelir kaydı silindi.")
            else:
                print("  ℹ  Silme işlemi iptal edildi.")
            return

    # Giderler içinde ara
    for i, islem in enumerate(yonetici.giderler):
        if islem.id == hedef_id:
            if onay_al(f"  '{islem}' silinsin mi?"):
                yonetici.giderler.pop(i)
                print("  ✅  Gider kaydı silindi.")
            else:
                print("  ℹ  Silme işlemi iptal edildi.")
            return

    print(f"  ⚠  ID={hedef_id} ile eşleşen işlem bulunamadı.")
