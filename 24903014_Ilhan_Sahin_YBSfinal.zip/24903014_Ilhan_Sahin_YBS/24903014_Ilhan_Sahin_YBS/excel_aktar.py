"""
excel_aktar.py
--------------
Kişisel Finans ve Harcama Takip Sistemi - Excel Aktarım
Tüm işlemler + aylık özet tablosu → tek .xlsx dosyası (openpyxl ile).
Aylık özet sayfası, CSV değiştiğinde otomatik olarak güncellenir.
"""

import os
from datetime import datetime
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import (
    PatternFill, Font, Alignment, Border, Side, numbers
)
from openpyxl.utils import get_column_letter

from analiz import verileri_dataframe_yap, aylik_analiz, numpy_istatistik, toplam_gelir_gider
from finans_modeli import FinansYoneticisi
from utils import baslik_yazdir

EXCEL_DOSYASI = "finans_raporu.xlsx"

# Renk sabitleri (ARGB hex)
YESIL   = "FF2ECC71"
KIRMIZI = "FFE74C3C"
MAVI    = "FF3498DB"
KOYU_BG = "FF1E1E2E"
BASLIK_BG = "FF313244"
ACIK_SATIR = "FF45475A"
BEYAZ   = "FFCDD6F4"
SIYAH   = "FF11111B"


# ====================================================================== #
#  Yardımcı Biçimlendirme                                                 #
# ====================================================================== #

def _kenar(ince: bool = True) -> Border:
    stil = "thin" if ince else "medium"
    yan = Side(style=stil, color="FF585B70")
    return Border(left=yan, right=yan, top=yan, bottom=yan)


def _doldur(hex_renk: str) -> PatternFill:
    return PatternFill(start_color=hex_renk, end_color=hex_renk, fill_type="solid")


def _font(kalin: bool = False, renk: str = BEYAZ, boyut: int = 11) -> Font:
    return Font(name="Calibri", bold=kalin, color=renk, size=boyut)


def _hucre_ayarla(ws, satir, sutun, deger, kalin=False,
                   renk=BEYAZ, bg=None, hizalama="left",
                   sayi_formati=None, boyut=11):
    hucre = ws.cell(row=satir, column=sutun, value=deger)
    hucre.font = _font(kalin=kalin, renk=renk, boyut=boyut)
    hucre.alignment = Alignment(horizontal=hizalama, vertical="center")
    hucre.border = _kenar()
    if bg:
        hucre.fill = _doldur(bg)
    if sayi_formati:
        hucre.number_format = sayi_formati
    return hucre


# ====================================================================== #
#  Sayfa 1 – Tüm İşlemler                                                 #
# ====================================================================== #

def _islemler_sayfasi(wb: Workbook, df: pd.DataFrame) -> None:
    ws = wb.active
    ws.title = "İşlemler"
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A3"

    # ── Başlık satırı ──────────────────────────────────────────────────
    basliklar = ["ID", "Tarih", "Tür", "Açıklama", "Tutar (TL)"]
    genislikler = [8, 14, 10, 35, 16]

    ws.row_dimensions[1].height = 14
    ws.row_dimensions[2].height = 26

    _hucre_ayarla(ws, 1, 1, "💰  Kişisel Finans Takip – İşlem Listesi",
                  kalin=True, renk=BEYAZ, bg=KOYU_BG, boyut=13, hizalama="center")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=5)
    ws.cell(1, 1).font = Font(name="Calibri", bold=True, color=BEYAZ, size=13)

    for idx, (baslik, genislik) in enumerate(zip(basliklar, genislikler), start=1):
        _hucre_ayarla(ws, 2, idx, baslik, kalin=True,
                      renk=BEYAZ, bg=BASLIK_BG, hizalama="center")
        ws.column_dimensions[get_column_letter(idx)].width = genislik

    # ── Veri satırları ─────────────────────────────────────────────────
    for satir_no, (_, satir) in enumerate(df.iterrows(), start=3):
        bg = "FF252535" if satir_no % 2 == 0 else KOYU_BG
        tip = satir["tip"]
        tutar_rengi = YESIL if tip == "gelir" else KIRMIZI

        _hucre_ayarla(ws, satir_no, 1, int(satir["id"]), bg=bg, hizalama="center")
        _hucre_ayarla(ws, satir_no, 2,
                      satir["tarih"].strftime("%Y-%m-%d") if hasattr(satir["tarih"], "strftime") else str(satir["tarih"]),
                      bg=bg, hizalama="center")
        _hucre_ayarla(ws, satir_no, 3, tip.upper(), kalin=True,
                      renk=tutar_rengi, bg=bg, hizalama="center")
        _hucre_ayarla(ws, satir_no, 4, satir["aciklama"], bg=bg)

        # Tutar – pozitif/negatif göster
        isaret = 1 if tip == "gelir" else -1
        _hucre_ayarla(ws, satir_no, 5, float(satir["tutar"]) * isaret,
                      renk=tutar_rengi, bg=bg, hizalama="right",
                      sayi_formati='#,##0.00 "₺"')

    # ── Özet satırı ───────────────────────────────────────────────────
    son_satir = len(df) + 3
    ws.row_dimensions[son_satir].height = 22
    ozet = toplam_gelir_gider(df)

    ws.merge_cells(start_row=son_satir, start_column=1, end_row=son_satir, end_column=3)
    _hucre_ayarla(ws, son_satir, 1, "TOPLAM ÖZET", kalin=True,
                  renk=BEYAZ, bg=BASLIK_BG, hizalama="center")

    _hucre_ayarla(ws, son_satir, 4, "Net Bakiye:",
                  kalin=True, renk=BEYAZ, bg=BASLIK_BG, hizalama="right")
    net_renk = YESIL if ozet["net_bakiye"] >= 0 else KIRMIZI
    _hucre_ayarla(ws, son_satir, 5, ozet["net_bakiye"],
                  kalin=True, renk=net_renk, bg=BASLIK_BG,
                  hizalama="right", sayi_formati='#,##0.00 "₺"')


# ====================================================================== #
#  Sayfa 2 – Aylık Özet (Güncellenebilir Tablo)                           #
# ====================================================================== #

def _aylik_ozet_sayfasi(wb: Workbook, df: pd.DataFrame) -> None:
    ws = wb.create_sheet(title="Aylık Özet")
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A3"

    basliklar = ["Ay", "Toplam Gelir", "Toplam Gider", "Net Bakiye", "Durum"]
    genislikler = [14, 18, 18, 18, 14]

    # Sayfa başlığı
    ws.row_dimensions[1].height = 14
    ws.row_dimensions[2].height = 26
    _hucre_ayarla(ws, 1, 1, "📅  Aylık Gelir / Gider Özeti",
                  kalin=True, renk=BEYAZ, bg=KOYU_BG, boyut=13, hizalama="center")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=5)
    ws.cell(1, 1).font = Font(name="Calibri", bold=True, color=BEYAZ, size=13)

    for idx, (baslik, genislik) in enumerate(zip(basliklar, genislikler), start=1):
        _hucre_ayarla(ws, 2, idx, baslik, kalin=True,
                      renk=BEYAZ, bg=BASLIK_BG, hizalama="center")
        ws.column_dimensions[get_column_letter(idx)].width = genislik

    # Veri
    aylik = aylik_analiz(df)
    for satir_no, (_, satir) in enumerate(aylik.iterrows(), start=3):
        bg = "FF252535" if satir_no % 2 == 0 else KOYU_BG
        net = satir["net_bakiye"]
        net_renk = YESIL if net >= 0 else KIRMIZI
        durum = "✅ Kâr" if net >= 0 else "⚠ Zarar"

        _hucre_ayarla(ws, satir_no, 1, satir["ay"], bg=bg, hizalama="center")
        _hucre_ayarla(ws, satir_no, 2, float(satir["toplam_gelir"]),
                      renk=YESIL, bg=bg, hizalama="right",
                      sayi_formati='#,##0.00 "₺"')
        _hucre_ayarla(ws, satir_no, 3, float(satir["toplam_gider"]),
                      renk=KIRMIZI, bg=bg, hizalama="right",
                      sayi_formati='#,##0.00 "₺"')
        _hucre_ayarla(ws, satir_no, 4, float(net),
                      kalin=True, renk=net_renk, bg=bg,
                      hizalama="right", sayi_formati='#,##0.00 "₺"')
        _hucre_ayarla(ws, satir_no, 5, durum, renk=net_renk,
                      bg=bg, hizalama="center")


# ====================================================================== #
#  Sayfa 3 – NumPy İstatistikleri                                         #
# ====================================================================== #

def _istatistik_sayfasi(wb: Workbook, df: pd.DataFrame) -> None:
    ws = wb.create_sheet(title="İstatistikler")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 18
    ws.column_dimensions["D"].width = 18

    _hucre_ayarla(ws, 1, 1, "🔢  NumPy İstatistiksel Özet",
                  kalin=True, renk=BEYAZ, bg=KOYU_BG, boyut=13)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=4)
    ws.cell(1, 1).font = Font(name="Calibri", bold=True, color=BEYAZ, size=13)

    ws.row_dimensions[2].height = 22
    for idx, baslik in enumerate(["İstatistik", "Gelir", "Gider", "Tümü"], start=1):
        _hucre_ayarla(ws, 2, idx, baslik, kalin=True,
                      renk=BEYAZ, bg=BASLIK_BG, hizalama="center")

    istat = numpy_istatistik(df)
    satirlar = [
        ("Ortalama", "ortalama"),
        ("Minimum",  "min"),
        ("Maksimum", "max"),
        ("Std. Sapma", "std"),
        ("Medyan",   "medyan"),
    ]

    for satir_no, (etiket, anahtar) in enumerate(satirlar, start=3):
        bg = "FF252535" if satir_no % 2 == 0 else KOYU_BG
        _hucre_ayarla(ws, satir_no, 1, etiket, kalin=True, bg=bg)
        for sutun, tip in [(2, "gelir"), (3, "gider"), (4, "tum")]:
            deger = istat.get(f"{tip}_{anahtar}")
            _hucre_ayarla(ws, satir_no, sutun,
                          deger if deger is not None else "—",
                          bg=bg, hizalama="right",
                          sayi_formati='#,##0.00 "₺"' if deger is not None else None)

    # Oluşturma zamanı
    ws.cell(row=len(satirlar) + 4, column=1,
            value=f"Oluşturulma: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    ws.cell(row=len(satirlar) + 4, column=1).font = Font(italic=True, color="FF585B70", size=9)


# ====================================================================== #
#  Ana Aktarım Fonksiyonu                                                  #
# ====================================================================== #

def excel_aktar(yonetici: FinansYoneticisi, dosya_adi: str = EXCEL_DOSYASI) -> None:
    """
    Tüm verileri üç sayfalı, biçimlendirilmiş bir Excel dosyasına aktarır:
      - Sayfa 1: İşlemler (tüm gelir & gider satırları)
      - Sayfa 2: Aylık Özet (CSV gibi otomatik güncellenen tablo)
      - Sayfa 3: İstatistikler (NumPy sonuçları)

    Parameters
    ----------
    yonetici  : FinansYoneticisi
    dosya_adi : str  –  Çıktı .xlsx dosya adı
    """
    baslik_yazdir(f"📥  EXCEL AKTAR → {dosya_adi}")

    df = verileri_dataframe_yap(yonetici)

    if df.empty:
        print("  ℹ  Aktarılacak veri yok.")
        return

    try:
        wb = Workbook()

        # Sayfa 1 – İşlemler
        _islemler_sayfasi(wb, df)

        # Sayfa 2 – Aylık Özet
        _aylik_ozet_sayfasi(wb, df)

        # Sayfa 3 – İstatistikler
        _istatistik_sayfasi(wb, df)

        # İlk sayfayı aktif yap
        wb.active = wb["İşlemler"]

        wb.save(dosya_adi)
        print(f"  ✅  Excel raporu oluşturuldu → {dosya_adi}")
        print(f"       Sayfa 1: İşlemler ({len(df)} kayıt)")
        print(f"       Sayfa 2: Aylık Özet")
        print(f"       Sayfa 3: İstatistikler")

    except Exception as hata:
        print(f"  ❌  Excel aktarım hatası: {hata}")
