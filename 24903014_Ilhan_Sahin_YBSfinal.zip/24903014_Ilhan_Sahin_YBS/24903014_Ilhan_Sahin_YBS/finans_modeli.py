"""
finans_modeli.py
----------------
Kişisel Finans ve Harcama Takip Sistemi - Veri Modelleri
Islem sınıfı: Tüm gelir ve gider kayıtlarının temel yapı taşı.
"""


class Islem:
    """
    Tek bir finansal işlemi temsil eden sınıf.

    Attributes
    ----------
    id        : int   – Benzersiz kayıt numarası
    tutar     : float – İşlem tutarı (TL)
    tarih     : str   – YYYY-MM-DD formatında tarih
    aciklama  : str   – Kısa açıklama / kategori
    tip       : str   – 'gelir' ya da 'gider'
    """

    def __init__(self, id: int, tutar: float, tarih: str, aciklama: str, tip: str):
        self.id = id
        self.tutar = tutar
        self.tarih = tarih
        self.aciklama = aciklama
        self.tip = tip.lower().strip()

    # ------------------------------------------------------------------ #
    #  Dunder metotlar                                                     #
    # ------------------------------------------------------------------ #

    def __repr__(self) -> str:
        return (
            f"Islem(id={self.id}, tip='{self.tip}', "
            f"tutar={self.tutar:.2f} TL, tarih='{self.tarih}', "
            f"aciklama='{self.aciklama}')"
        )

    def __str__(self) -> str:
        sembol = "+" if self.tip == "gelir" else "-"
        return (
            f"[{self.id:>4}] {self.tarih}  {sembol}{self.tutar:>10.2f} TL  "
            f"{'(' + self.tip.upper() + ')':10}  {self.aciklama}"
        )

    # ------------------------------------------------------------------ #
    #  Yardımcı dönüşüm                                                    #
    # ------------------------------------------------------------------ #

    def sozluge_donustur(self) -> dict:
        """İşlemi CSV/Excel'e yazılabilir bir sözlük olarak döndürür."""
        return {
            "id": self.id,
            "tutar": self.tutar,
            "tarih": self.tarih,
            "aciklama": self.aciklama,
            "tip": self.tip,
        }


class FinansYoneticisi:
    """
    Tüm işlem listelerini (gelir + gider) tek noktadan yöneten konteyner.
    Diğer modüller bu sınıfı kullanarak veriye erişir.
    """

    def __init__(self):
        self.gelirler: list[Islem] = []
        self.giderler: list[Islem] = []

    # ------------------------------------------------------------------ #
    #  Kısa yardımcılar                                                    #
    # ------------------------------------------------------------------ #

    def tum_islemler(self) -> list[Islem]:
        """Gelir ve giderleri tek listede birleştirerek döndürür."""
        return self.gelirler + self.giderler

    def toplam_gelir(self) -> float:
        return sum(i.tutar for i in self.gelirler)

    def toplam_gider(self) -> float:
        return sum(i.tutar for i in self.giderler)

    def net_bakiye(self) -> float:
        return self.toplam_gelir() - self.toplam_gider()

    def __repr__(self) -> str:
        return (
            f"FinansYoneticisi("
            f"gelir_sayisi={len(self.gelirler)}, "
            f"gider_sayisi={len(self.giderler)}, "
            f"net_bakiye={self.net_bakiye():.2f} TL)"
        )
