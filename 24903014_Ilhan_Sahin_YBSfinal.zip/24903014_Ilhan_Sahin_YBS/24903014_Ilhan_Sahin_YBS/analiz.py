"""
analiz.py
---------
Kişisel Finans ve Harcama Takip Sistemi - Veri Analizi
Pandas DataFrame dönüşümü, aylık analiz ve NumPy istatistikleri.
"""

import numpy as np
import pandas as pd
from finans_modeli import FinansYoneticisi
from utils import baslik_yazdir


# ====================================================================== #
#  DataFrame Dönüşümü                                                     #
# ====================================================================== #

def verileri_dataframe_yap(yonetici: FinansYoneticisi) -> pd.DataFrame:
    """
    Gelir ve gider listelerini birleştirerek pandas DataFrame'e dönüştürür.
    'tarih' sütunu datetime tipine, 'ay' sütunu YYYY-MM formatına çevrilir.

    Parameters
    ----------
    yonetici : FinansYoneticisi

    Returns
    -------
    pd.DataFrame
        Sütunlar: id, tutar, tarih, aciklama, tip, ay
    """
    kayitlar = [i.sozluge_donustur() for i in yonetici.tum_islemler()]

    if not kayitlar:
        # Boş ama tutarlı bir DataFrame döndür
        return pd.DataFrame(columns=["id", "tutar", "tarih", "aciklama", "tip", "ay"])

    df = pd.DataFrame(kayitlar)
    df["tarih"] = pd.to_datetime(df["tarih"], format="%Y-%m-%d", errors="coerce")
    df["ay"] = df["tarih"].dt.to_period("M").astype(str)
    df = df.sort_values("tarih").reset_index(drop=True)
    return df


# ====================================================================== #
#  Temel Analiz                                                            #
# ====================================================================== #

def toplam_gelir_gider(df: pd.DataFrame) -> dict:
    """
    DataFrame üzerinden toplam gelir, gider ve net bakiyeyi hesaplar.

    Returns
    -------
    dict  →  {'toplam_gelir': float, 'toplam_gider': float, 'net_bakiye': float}
    """
    toplam_gelir = df.loc[df["tip"] == "gelir", "tutar"].sum()
    toplam_gider = df.loc[df["tip"] == "gider", "tutar"].sum()
    return {
        "toplam_gelir": round(toplam_gelir, 2),
        "toplam_gider": round(toplam_gider, 2),
        "net_bakiye": round(toplam_gelir - toplam_gider, 2),
    }


def aylik_analiz(df: pd.DataFrame) -> pd.DataFrame:
    """
    Verileri aya göre gruplayarak gelir/gider/net özetini döndürür.

    Returns
    -------
    pd.DataFrame
        Sütunlar: ay, toplam_gelir, toplam_gider, net_bakiye
    """
    if df.empty:
        return pd.DataFrame(columns=["ay", "toplam_gelir", "toplam_gider", "net_bakiye"])

    pivot = (
        df.groupby(["ay", "tip"])["tutar"]
        .sum()
        .unstack(fill_value=0)
        .reset_index()
    )

    # Her iki tip her zaman var olmayabilir → eksikleri sıfırla
    for sutun in ("gelir", "gider"):
        if sutun not in pivot.columns:
            pivot[sutun] = 0.0

    pivot = pivot.rename(columns={"gelir": "toplam_gelir", "gider": "toplam_gider"})
    pivot["net_bakiye"] = pivot["toplam_gelir"] - pivot["toplam_gider"]
    pivot = pivot.sort_values("ay").reset_index(drop=True)

    # Yuvarlama
    for col in ("toplam_gelir", "toplam_gider", "net_bakiye"):
        pivot[col] = pivot[col].round(2)

    return pivot


def numpy_istatistik(df: pd.DataFrame) -> dict:
    """
    NumPy kullanarak işlem tutarları üzerinde temel istatistikler hesaplar.
    Gelir ve gider ayrı ayrı, ayrıca tümü için hesaplanır.

    Returns
    -------
    dict  →  istatistik adı → değer
    """
    if df.empty:
        return {}

    gelir_arr = df.loc[df["tip"] == "gelir", "tutar"].to_numpy(dtype=float)
    gider_arr = df.loc[df["tip"] == "gider", "tutar"].to_numpy(dtype=float)
    tum_arr = df["tutar"].to_numpy(dtype=float)

    def ozet(arr: np.ndarray, etiket: str) -> dict:
        if len(arr) == 0:
            return {f"{etiket}_ortalama": None, f"{etiket}_min": None,
                    f"{etiket}_max": None, f"{etiket}_std": None,
                    f"{etiket}_medyan": None}
        return {
            f"{etiket}_ortalama": round(float(np.mean(arr)), 2),
            f"{etiket}_min":      round(float(np.min(arr)), 2),
            f"{etiket}_max":      round(float(np.max(arr)), 2),
            f"{etiket}_std":      round(float(np.std(arr)), 2),
            f"{etiket}_medyan":   round(float(np.median(arr)), 2),
        }

    istatistikler = {}
    istatistikler.update(ozet(gelir_arr, "gelir"))
    istatistikler.update(ozet(gider_arr, "gider"))
    istatistikler.update(ozet(tum_arr, "tum"))
    return istatistikler


# ====================================================================== #
#  Konsol Çıktısı                                                         #
# ====================================================================== #

def analiz_goster(yonetici: FinansYoneticisi) -> None:
    """
    Tüm analizleri birleştirerek ekrana düzenli şekilde yazdırır.

    Parameters
    ----------
    yonetici : FinansYoneticisi
    """
    baslik_yazdir("📊  FİNANSAL ANALİZ")

    df = verileri_dataframe_yap(yonetici)

    if df.empty:
        print("  ℹ  Analiz yapılacak veri yok.")
        return

    # ── Genel Özet ──────────────────────────────────────────────────────
    ozet = toplam_gelir_gider(df)
    print("\n  📌  GENEL ÖZET")
    print(f"  {'Toplam Gelir':<20}: \033[92m{ozet['toplam_gelir']:>12.2f} TL\033[0m")
    print(f"  {'Toplam Gider':<20}: \033[91m{ozet['toplam_gider']:>12.2f} TL\033[0m")
    net = ozet["net_bakiye"]
    renk = "\033[92m" if net >= 0 else "\033[91m"
    print(f"  {'Net Bakiye':<20}: {renk}{net:>+12.2f} TL\033[0m")

    # ── Aylık Analiz ────────────────────────────────────────────────────
    aylik = aylik_analiz(df)
    print("\n  📅  AYLIK ÖZET")
    print(f"  {'AY':^10}  {'GELİR':>12}  {'GİDER':>12}  {'NET':>12}")
    print("  " + "─" * 50)
    for _, satir in aylik.iterrows():
        net_r = satir["net_bakiye"]
        renk = "\033[92m" if net_r >= 0 else "\033[91m"
        print(
            f"  {satir['ay']:^10}  "
            f"\033[92m{satir['toplam_gelir']:>10.2f} TL\033[0m  "
            f"\033[91m{satir['toplam_gider']:>10.2f} TL\033[0m  "
            f"{renk}{net_r:>+10.2f} TL\033[0m"
        )

    # ── NumPy İstatistikleri ─────────────────────────────────────────────
    istat = numpy_istatistik(df)
    print("\n  🔢  NUMPY İSTATİSTİKLERİ")

    for tip, etiket in [("gelir", "Gelir"), ("gider", "Gider"), ("tum", "Tüm")]:
        ort = istat.get(f"{tip}_ortalama")
        if ort is None:
            continue
        print(f"\n    [{etiket}]")
        print(f"    {'Ortalama':<12}: {ort:>10.2f} TL")
        print(f"    {'Min':<12}: {istat[f'{tip}_min']:>10.2f} TL")
        print(f"    {'Max':<12}: {istat[f'{tip}_max']:>10.2f} TL")
        print(f"    {'Std. Sapma':<12}: {istat[f'{tip}_std']:>10.2f} TL")
        print(f"    {'Medyan':<12}: {istat[f'{tip}_medyan']:>10.2f} TL")
