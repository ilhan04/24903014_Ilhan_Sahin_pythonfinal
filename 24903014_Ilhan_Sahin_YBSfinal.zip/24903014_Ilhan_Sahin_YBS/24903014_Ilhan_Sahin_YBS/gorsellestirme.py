"""
gorsellestirme.py
-----------------
Kişisel Finans ve Harcama Takip Sistemi - Görselleştirme
Aylık çizgi grafiği, sütun grafiği ve pasta grafiği.
"""

import matplotlib
matplotlib.use("Agg")   # GUI olmayan ortamlarda çalışabilmek için
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import pandas as pd
import os
from analiz import verileri_dataframe_yap, aylik_analiz, toplam_gelir_gider
from finans_modeli import FinansYoneticisi
from utils import baslik_yazdir

# Grafiklerin kaydedileceği klasör
GRAFIK_KLASORU = "grafikler"

# Renk paleti
RENK_GELIR = "#2ecc71"
RENK_GIDER = "#e74c3c"
RENK_NET = "#3498db"
ARKA_PLAN = "#1e1e2e"
YAZI_RENGI = "#cdd6f4"


def _grafik_klasoru_hazirla() -> None:
    """Grafik kayıt klasörünü oluşturur (yoksa)."""
    os.makedirs(GRAFIK_KLASORU, exist_ok=True)


def _stil_uygula(ax: plt.Axes, baslik: str) -> None:
    """Tüm grafiklere ortak koyu tema uygular."""
    ax.set_facecolor(ARKA_PLAN)
    ax.figure.set_facecolor(ARKA_PLAN)
    ax.title.set_color(YAZI_RENGI)
    ax.xaxis.label.set_color(YAZI_RENGI)
    ax.yaxis.label.set_color(YAZI_RENGI)
    ax.tick_params(colors=YAZI_RENGI)
    for spine in ax.spines.values():
        spine.set_edgecolor("#45475a")
    ax.set_title(baslik, fontsize=14, fontweight="bold", pad=15)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f} ₺"))


# ====================================================================== #
#  Grafik 1 – Aylık Çizgi Grafiği                                         #
# ====================================================================== #

def aylik_grafik(df: pd.DataFrame) -> str | None:
    """
    Aylık gelir ve giderleri karşılaştıran çizgi grafiği oluşturur
    ve dosyaya kaydeder.

    Parameters
    ----------
    df : pd.DataFrame  –  verileri_dataframe_yap() çıktısı

    Returns
    -------
    str | None  –  Kaydedilen dosya yolu ya da None (veri yoksa)
    """
    aylik = aylik_analiz(df)
    if aylik.empty:
        print("  ⚠  Aylık grafik için yeterli veri yok.")
        return None

    _grafik_klasoru_hazirla()
    fig, ax = plt.subplots(figsize=(10, 5))

    ax.plot(aylik["ay"], aylik["toplam_gelir"], marker="o",
            color=RENK_GELIR, linewidth=2.5, label="Gelir", markersize=7)
    ax.plot(aylik["ay"], aylik["toplam_gider"], marker="s",
            color=RENK_GIDER, linewidth=2.5, label="Gider", markersize=7)
    ax.plot(aylik["ay"], aylik["net_bakiye"], marker="^",
            color=RENK_NET, linewidth=1.5, linestyle="--", label="Net", markersize=6)

    ax.fill_between(aylik["ay"], aylik["toplam_gelir"], alpha=0.1, color=RENK_GELIR)
    ax.fill_between(aylik["ay"], aylik["toplam_gider"], alpha=0.1, color=RENK_GIDER)

    ax.axhline(0, color="#585b70", linewidth=0.8, linestyle=":")
    ax.set_xlabel("Ay", fontsize=11)
    ax.set_ylabel("Tutar (TL)", fontsize=11)
    ax.legend(facecolor="#313244", labelcolor=YAZI_RENGI, fontsize=10)
    ax.grid(axis="y", color="#313244", linewidth=0.6)
    plt.xticks(rotation=45, ha="right")
    _stil_uygula(ax, "📈  Aylık Gelir / Gider Karşılaştırması")

    plt.tight_layout()
    yol = os.path.join(GRAFIK_KLASORU, "aylik_cizgi.png")
    plt.savefig(yol, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✅  Aylık çizgi grafiği kaydedildi → {yol}")
    return yol


# ====================================================================== #
#  Grafik 2 – Sütun Grafiği (Toplam Gelir vs Gider)                       #
# ====================================================================== #

def gelir_gider_bar(df: pd.DataFrame) -> str | None:
    """
    Toplam gelir ve gider değerlerini karşılaştıran sütun grafiği oluşturur.

    Returns
    -------
    str | None  –  Kaydedilen dosya yolu
    """
    ozet = toplam_gelir_gider(df)
    if not any(ozet.values()):
        print("  ⚠  Sütun grafiği için yeterli veri yok.")
        return None

    _grafik_klasoru_hazirla()
    fig, ax = plt.subplots(figsize=(7, 5))

    kategoriler = ["Gelir", "Gider", "Net Bakiye"]
    degerler = [ozet["toplam_gelir"], ozet["toplam_gider"], ozet["net_bakiye"]]
    renkler = [RENK_GELIR, RENK_GIDER, RENK_NET if ozet["net_bakiye"] >= 0 else RENK_GIDER]

    bars = ax.bar(kategoriler, degerler, color=renkler,
                  width=0.5, edgecolor="#45475a", linewidth=1.2)

    # Değer etiketleri
    for bar, val in zip(bars, degerler):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + max(degerler) * 0.02,
            f"{val:,.0f} ₺",
            ha="center", va="bottom",
            color=YAZI_RENGI, fontsize=10, fontweight="bold"
        )

    ax.set_ylabel("Tutar (TL)", fontsize=11)
    ax.grid(axis="y", color="#313244", linewidth=0.6)
    _stil_uygula(ax, "📊  Toplam Gelir / Gider Karşılaştırması")

    plt.tight_layout()
    yol = os.path.join(GRAFIK_KLASORU, "gelir_gider_bar.png")
    plt.savefig(yol, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✅  Sütun grafiği kaydedildi → {yol}")
    return yol


# ====================================================================== #
#  Grafik 3 – Pasta Grafiği                                               #
# ====================================================================== #

def pasta_grafik(df: pd.DataFrame) -> str | None:
    """
    Gelir ve gider oranlarını gösteren pasta grafiği oluşturur.

    Returns
    -------
    str | None  –  Kaydedilen dosya yolu
    """
    ozet = toplam_gelir_gider(df)
    gelir = ozet["toplam_gelir"]
    gider = ozet["toplam_gider"]

    if gelir == 0 and gider == 0:
        print("  ⚠  Pasta grafiği için yeterli veri yok.")
        return None

    _grafik_klasoru_hazirla()
    fig, ax = plt.subplots(figsize=(7, 5))

    boyutlar = [gelir, gider]
    etiketler = [f"Gelir\n{gelir:,.0f} ₺", f"Gider\n{gider:,.0f} ₺"]
    renkler = [RENK_GELIR, RENK_GIDER]
    patlamalar = (0.05, 0.05)

    wedges, texts, autotexts = ax.pie(
        boyutlar,
        labels=etiketler,
        autopct="%1.1f%%",
        startangle=140,
        colors=renkler,
        explode=patlamalar,
        pctdistance=0.75,
        wedgeprops={"edgecolor": ARKA_PLAN, "linewidth": 2},
    )

    for text in texts:
        text.set_color(YAZI_RENGI)
        text.set_fontsize(11)
    for autotext in autotexts:
        autotext.set_color("white")
        autotext.set_fontsize(10)
        autotext.set_fontweight("bold")

    ax.figure.set_facecolor(ARKA_PLAN)
    ax.set_title("🥧  Gelir / Gider Oranı", fontsize=14,
                 fontweight="bold", color=YAZI_RENGI, pad=15)

    plt.tight_layout()
    yol = os.path.join(GRAFIK_KLASORU, "pasta.png")
    plt.savefig(yol, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✅  Pasta grafiği kaydedildi → {yol}")
    return yol


# ====================================================================== #
#  Menü Yardımcısı                                                         #
# ====================================================================== #

def grafik_menu(yonetici: FinansYoneticisi) -> None:
    """Grafik seçim menüsünü gösterir ve seçilen grafiği oluşturur."""
    baslik_yazdir("📈  GRAFİK GÖSTER")
    print("  1  Aylık Çizgi Grafiği")
    print("  2  Sütun Grafiği (Toplam Gelir vs Gider)")
    print("  3  Pasta Grafiği (Oran)")
    print("  4  Tüm Grafikleri Oluştur")
    print("  5  Geri")

    df = verileri_dataframe_yap(yonetici)

    if df.empty:
        print("\n  ℹ  Grafik oluşturmak için veri ekleyin.")
        return

    secim = input("\n  Seçiminiz: ").strip()

    if secim == "1":
        aylik_grafik(df)
    elif secim == "2":
        gelir_gider_bar(df)
    elif secim == "3":
        pasta_grafik(df)
    elif secim == "4":
        aylik_grafik(df)
        gelir_gider_bar(df)
        pasta_grafik(df)
        print(f"\n  📁  Tüm grafikler '{GRAFIK_KLASORU}/' klasörüne kaydedildi.")
    elif secim == "5":
        return
    else:
        print("  ⚠  Geçersiz seçim.")
