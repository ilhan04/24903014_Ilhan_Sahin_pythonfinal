"""
utils.py
--------
Kişisel Finans ve Harcama Takip Sistemi - Yardımcı Fonksiyonlar
Doğrulama, ID üretimi ve menü gibi genel amaçlı araçlar.
"""

import re
from datetime import datetime


# ====================================================================== #
#  ID Yönetimi                                                            #
# ====================================================================== #

def yeni_id_olustur(liste: list) -> int:
    """
    Verilen listedeki en büyük id değerini bulup 1 artırarak
    benzersiz yeni bir ID döndürür.

    Parameters
    ----------
    liste : list[Islem]
        Mevcut işlem listesi (gelirler veya giderler).

    Returns
    -------
    int
        Kullanılabilecek yeni ID.
    """
    if not liste:
        return 1
    return max(islem.id for islem in liste) + 1


def benzersiz_id_olustur(gelirler: list, giderler: list) -> int:
    """
    Hem gelir hem gider listesi üzerinden çakışmayan yeni ID üretir.
    """
    tum_liste = gelirler + giderler
    return yeni_id_olustur(tum_liste) if tum_liste else 1


# ====================================================================== #
#  Doğrulama Fonksiyonları                                                #
# ====================================================================== #

def tarih_kontrol(tarih: str) -> bool:
    """
    Girilen tarihin YYYY-MM-DD formatında geçerli olup olmadığını kontrol eder.

    Parameters
    ----------
    tarih : str
        Kontrol edilecek tarih dizesi.

    Returns
    -------
    bool
        Geçerliyse True, değilse False.
    """
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", tarih):
        return False
    try:
        datetime.strptime(tarih, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def sayi_kontrol(deger: str) -> bool:
    """
    Kullanıcıdan alınan değerin pozitif bir sayıya dönüştürülebilir
    olup olmadığını kontrol eder.

    Parameters
    ----------
    deger : str
        Kontrol edilecek karakter dizesi.

    Returns
    -------
    bool
        Geçerliyse True, değilse False.
    """
    try:
        return float(deger) > 0
    except (ValueError, TypeError):
        return False


def bugunku_tarih() -> str:
    """Bugünün tarihini YYYY-MM-DD formatında döndürür."""
    return datetime.today().strftime("%Y-%m-%d")


# ====================================================================== #
#  Kullanıcı Girdisi Alma                                                 #
# ====================================================================== #

def guvenli_tutar_al(mesaj: str) -> float:
    """
    Kullanıcıdan doğrulanmış pozitif bir tutar alır.
    Hatalı girişte tekrar sorar.
    """
    while True:
        girdi = input(mesaj).strip().replace(",", ".")
        if sayi_kontrol(girdi):
            return float(girdi)
        print("  ⚠  Geçersiz tutar! Lütfen pozitif bir sayı giriniz.")


def guvenli_tarih_al(mesaj: str) -> str:
    """
    Kullanıcıdan YYYY-MM-DD formatında geçerli tarih alır.
    Enter'a basılırsa bugünün tarihi kullanılır.
    """
    bugun = bugunku_tarih()
    while True:
        girdi = input(f"{mesaj} [Boş bırakırsanız bugün ({bugun})]: ").strip()
        if girdi == "":
            return bugun
        if tarih_kontrol(girdi):
            return girdi
        print("  ⚠  Geçersiz tarih! Format: YYYY-MM-DD (örn. 2026-06-01)")


def guvenli_aciklama_al(mesaj: str) -> str:
    """Boş geçilemeyen bir açıklama/kategori alır."""
    while True:
        girdi = input(mesaj).strip()
        if girdi:
            return girdi
        print("  ⚠  Açıklama boş bırakılamaz.")


# ====================================================================== #
#  Menü                                                                   #
# ====================================================================== #

def menu_goster() -> None:
    """Ana menüyü ekrana yazdırır."""
    print("\n" + "═" * 50)
    print("   💰  KİŞİSEL FİNANS TAKİP SİSTEMİ")
    print("═" * 50)
    print("  1  ➕  Gelir Ekle")
    print("  2  ➖  Gider Ekle")
    print("  3  📋  Listele")
    print("  4  📊  Analiz Yap")
    print("  5  📈  Grafik Göster")
    print("  6  💾  CSV Kaydet / Yükle")
    print("  7  📥  Excel'e Aktar")
    print("  8  🗑   İşlem Sil")
    print("  0  🚪  Çıkış")
    print("═" * 50)


def baslik_yazdir(baslik: str) -> None:
    """Bölüm başlığı yazdırır."""
    print(f"\n{'─' * 50}")
    print(f"  {baslik}")
    print(f"{'─' * 50}")


def onay_al(mesaj: str) -> bool:
    """E/H şeklinde onay alır."""
    cevap = input(f"{mesaj} (E/H): ").strip().lower()
    return cevap in ("e", "evet", "y", "yes")
