"""
dosya_islemleri.py
------------------
Kişisel Finans ve Harcama Takip Sistemi - Dosya İşlemleri
CSV okuma/yazma ve aylık özet tablosunu otomatik güncelleme.
"""

import csv
import os
from finans_modeli import Islem, FinansYoneticisi
from utils import baslik_yazdir

# Varsayılan dosya adları
VARSAYILAN_CSV = "islemler.csv"
AYLIK_OZET_CSV = "aylik_ozet.csv"

CSV_SUTUNLAR = ["id", "tutar", "tarih", "aciklama", "tip"]


# ====================================================================== #
#  CSV Kaydet / Oku                                                        #
# ====================================================================== #

def csv_kaydet(yonetici: FinansYoneticisi, dosya_adi: str = VARSAYILAN_CSV) -> None:
    """
    Tüm gelir ve gider verilerini CSV dosyasına kaydeder.
    Mevcut dosyanın üzerine yazar.

    Parameters
    ----------
    yonetici  : FinansYoneticisi
    dosya_adi : str – Hedef CSV dosyasının adı/yolu
    """
    baslik_yazdir(f"💾  CSV KAYDET → {dosya_adi}")

    tum = yonetici.tum_islemler()

    if not tum:
        print("  ℹ  Kaydedilecek işlem yok.")
        return

    try:
        with open(dosya_adi, mode="w", newline="", encoding="utf-8-sig") as f:
            yazar = csv.DictWriter(f, fieldnames=CSV_SUTUNLAR)
            yazar.writeheader()
            for islem in tum:
                yazar.writerow(islem.sozluge_donustur())

        print(f"  ✅  {len(tum)} işlem '{dosya_adi}' dosyasına kaydedildi.")

        # Aylık özet tablosunu da otomatik güncelle
        _aylik_ozet_csv_guncelle(yonetici)

    except OSError as hata:
        print(f"  ❌  Dosya yazma hatası: {hata}")


def csv_oku(yonetici: FinansYoneticisi, dosya_adi: str = VARSAYILAN_CSV) -> None:
    """
    CSV dosyasındaki verileri okuyarak yonetici listelerine aktarır.
    Mevcut listeyi temizleyip yeniden yükler.

    Parameters
    ----------
    yonetici  : FinansYoneticisi
    dosya_adi : str – Okunacak CSV dosyasının adı/yolu
    """
    baslik_yazdir(f"📂  CSV YÜKLE ← {dosya_adi}")

    if not os.path.exists(dosya_adi):
        print(f"  ⚠  '{dosya_adi}' bulunamadı. Boş liste ile devam ediliyor.")
        return

    try:
        yonetici.gelirler.clear()
        yonetici.giderler.clear()

        with open(dosya_adi, mode="r", newline="", encoding="utf-8-sig") as f:
            okuyucu = csv.DictReader(f)
            yuklenen = 0
            hatali = 0

            for satir in okuyucu:
                try:
                    islem = Islem(
                        id=int(satir["id"]),
                        tutar=float(satir["tutar"]),
                        tarih=satir["tarih"].strip(),
                        aciklama=satir["aciklama"].strip(),
                        tip=satir["tip"].strip().lower(),
                    )
                    if islem.tip == "gelir":
                        yonetici.gelirler.append(islem)
                    elif islem.tip == "gider":
                        yonetici.giderler.append(islem)
                    else:
                        print(f"  ⚠  Bilinmeyen tip: {islem.tip} (ID={islem.id})")
                        hatali += 1
                        continue
                    yuklenen += 1
                except (ValueError, KeyError) as satir_hatasi:
                    print(f"  ⚠  Hatalı satır atlandı: {satir_hatasi}")
                    hatali += 1

        print(f"  ✅  {yuklenen} işlem yüklendi.", end="")
        if hatali:
            print(f"  ({hatali} hatalı satır atlandı.)")
        else:
            print()

    except OSError as hata:
        print(f"  ❌  Dosya okuma hatası: {hata}")


# ====================================================================== #
#  Aylık Özet – Otomatik Güncellenen Tablo                                #
# ====================================================================== #

def _aylik_ozet_csv_guncelle(yonetici: FinansYoneticisi) -> None:
    """
    Aylık gelir/gider özetini ayrı bir CSV dosyasına (aylik_ozet.csv)
    yazar. csv_kaydet() çağrıldığında otomatik olarak tetiklenir, böylece
    tablo her zaman güncel kalır.

    Sütunlar: ay, toplam_gelir, toplam_gider, net_bakiye
    """
    from collections import defaultdict

    aylik: dict[str, dict] = defaultdict(lambda: {"toplam_gelir": 0.0, "toplam_gider": 0.0})

    for islem in yonetici.tum_islemler():
        # Tarihin ilk 7 karakteri → YYYY-MM
        ay = islem.tarih[:7]
        if islem.tip == "gelir":
            aylik[ay]["toplam_gelir"] += islem.tutar
        else:
            aylik[ay]["toplam_gider"] += islem.tutar

    if not aylik:
        return

    try:
        with open(AYLIK_OZET_CSV, mode="w", newline="", encoding="utf-8-sig") as f:
            yazar = csv.DictWriter(
                f,
                fieldnames=["ay", "toplam_gelir", "toplam_gider", "net_bakiye"],
            )
            yazar.writeheader()
            for ay in sorted(aylik.keys()):
                gelir = aylik[ay]["toplam_gelir"]
                gider = aylik[ay]["toplam_gider"]
                yazar.writerow(
                    {
                        "ay": ay,
                        "toplam_gelir": round(gelir, 2),
                        "toplam_gider": round(gider, 2),
                        "net_bakiye": round(gelir - gider, 2),
                    }
                )
        print(f"  🔄  Aylık özet güncellendi → {AYLIK_OZET_CSV}")
    except OSError as hata:
        print(f"  ❌  Aylık özet yazma hatası: {hata}")


# ====================================================================== #
#  Menü Yardımcısı                                                         #
# ====================================================================== #

def csv_menu(yonetici: FinansYoneticisi) -> None:
    """CSV işlemleri için alt menü sunar."""
    baslik_yazdir("💾  CSV İŞLEMLERİ")
    print("  1  Kaydet (mevcut verileri CSV'ye yaz)")
    print("  2  Yükle  (CSV'den verileri oku)")
    print("  3  Geri")

    secim = input("\n  Seçiminiz: ").strip()

    if secim == "1":
        dosya = input(f"  Dosya adı [{VARSAYILAN_CSV}]: ").strip() or VARSAYILAN_CSV
        csv_kaydet(yonetici, dosya)
    elif secim == "2":
        dosya = input(f"  Dosya adı [{VARSAYILAN_CSV}]: ").strip() or VARSAYILAN_CSV
        csv_oku(yonetici, dosya)
    elif secim == "3":
        return
    else:
        print("  ⚠  Geçersiz seçim.")
